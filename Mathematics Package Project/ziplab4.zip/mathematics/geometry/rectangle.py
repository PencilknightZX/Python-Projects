#File: mathematics/geometry/ rectangle.py

def perimeter(*,lenght,width):
    """ Returns the permiter of a rectangle given the lenght and width """
    return((2*lenght)+(2*width))

def area(*,lenght,width):
    """ Return the area of a recatngle given the lenght and  width """
    return(lenght * width)

        
