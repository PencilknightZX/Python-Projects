#File: mathematics/numbers/ simple.py

def addition(*,left, right):
    """ Returns the sum of the left and right values """
    return left + right

def subtraction(*,left, right):
    """ Returns the difference between the left and right values """
    return left - right

def multiplication(*,left, right):
    """ Returns the product of the left and right values """
    return left * right

def division(*,left, right):
    """ Returns the product of the left and right values """
    return left / right

