#File: mathematics/numbers/ __init__.py

__all__ = ["whoami", "series"]
