#File: mathematics/ whoami.py

def getname():
    """ return the name of the file """
    return __name__

